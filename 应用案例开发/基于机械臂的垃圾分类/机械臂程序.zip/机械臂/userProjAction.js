const Blockly = global.Blockly;

Blockly.Blocks['aelos_compare'] = {
  init: function () {
    this.jsonInit({
      "type": "aelos_compare",
      "message0": "%1 %2 %3",
      "args0": [{
        "type": "input_value",
        "name": "input_1",
        "check": ["Number", "Variable"]
      }, {
        "type": "field_dropdown",
        "name": "OP",
        "options": [
          [
            "=",
            "JNE"
          ],
          [
            "\u2260",
            "JE"
          ],
          [
            "<",
            "JAE"
          ],
          [
            "\u200f\u2265\u200f",
            "JA"
          ],
          [
            ">",
            "JBE"
          ],
          [
            "\u200f\u2264\u200f",
            "JB"
          ]
        ]
      }, {
        "type": "input_value",
        "name": "input_2",
        "check": ["Number", "Variable"]
      }],
      "inputsInline": true,
      "output": "Boolean",
      "colour": '#86C113',
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.JavaScript['aelos_compare'] = function (block) {
  var input_1 = Blockly.JavaScript.valueToCode(block, "input_1", Blockly.JavaScript.ORDER_ATOMIC) || "0";
  var input_2 = Blockly.JavaScript.valueToCode(block, "input_2", Blockly.JavaScript.ORDER_ATOMIC) || "0";
  var operation = block.getFieldValue("OP");

  //判断操作数类型
  var result1 = Blockly.JavaScript.judgeElement(input_1);
  var result2 = Blockly.JavaScript.judgeElement(input_2);

  var code = `CMP ${result1.code}${result2.code} ${result1.element} ${result2.element}\n${operation}`;
  return [code, Blockly.JavaScript.ORDER_NONE];
}

Blockly.Python['aelos_compare'] = function (block) {
  var op_map = {
    "JNE": "==",
    "JE": "!=",
    "JAE": "<",
    "JA": "<=",
    "JBE": ">",
    "JB": ">="
  };
  var input_1 = Blockly.Python.valueToCode(block, "input_1", Blockly.Python.ORDER_ATOMIC);
  var input_2 = Blockly.Python.valueToCode(block, "input_2", Blockly.Python.ORDER_ATOMIC);
  var operation = op_map[block.getFieldValue("OP")];
  var code = "";

  if (input_1 && input_2) {
    code = `${input_1} ${operation} ${input_2}`;
  } else {
    code = "FALSE";
  }

  return [code, Blockly.Python.ORDER_NONE];
}



Blockly.Blocks['aelos_if'] = {
  init: function () {
    this.jsonInit({
      "type": "aelos_if",
      "message0": "%{BKY_AELOS_IF} %1 %{BKY_AELOS_DO} %2",
      "args0": [
        {
          "type": "input_value",
          "name": "condition",
          "check": "Boolean"
        },
        {
          "type": "input_statement",
          "name": "do"
        }
      ],
      "previousStatement": null,
      "nextStatement": null,
      "colour": '#86C113',
      "toolip": "",
      "helpUrl": ""
    });
  }
};

Blockly.JavaScript['aelos_if'] = function (block) {
  var jmp_id = "id-" + md5(block.id);

  var condition = (Blockly.JavaScript.valueToCode(block, "condition", Blockly.JavaScript.ORDER_NONE) || "JMP") + " " + jmp_id + "\n";
  var do_code = Blockly.JavaScript.statementToCode(block, "do");

  var code = `${condition}${do_code}LABEL ${jmp_id}\n`;
  return code;
}

Blockly.Python['aelos_if'] = function (block) {
  var condition = Blockly.Python.valueToCode(block, "condition", Blockly.Python.ORDER_NONE) || "FALSE";
  var do_code = Blockly.Python.statementToCode(block, "do") || "  pass\n";

  var code = `if ${condition}:\n${do_code}`;
  return code;
}



Blockly.Blocks['air_pump'] = {
  init: function () {
    this.jsonInit({
      "type": "air_pump",
      "message0": "%{BKY_AIRPUMP} %1",
      "args0": [
        {
          "type": "field_dropdown",
          "name": "output_value",
          "options": [
            [
              "%{BKY_AIRPUMP_OFF}",
              "0"
            ],
            [
              "%{BKY_AIRPUMP_ON}",
              "1"
            ]
          ]
        }
      ],
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#36B7F4",
      "tooltip": "",
      "helpUrl": ""
    })
  }
};

Blockly.JavaScript['air_pump'] = function (block) {
  var code = '';
  var output_value = block.getFieldValue("output_value");

  if(output_value){
    output_value = Blockly.JavaScript.transferHex(output_value, 1);
    code = `IOout 07 ${output_value}\n`;
  }

  return code;
}

Blockly.Python['air_pump'] = function (block) {
  var code = '';
  var output_value = parseInt(block.getFieldValue("output_value"), 0);
  var air_pump_state;
  if(output_value === 1){
    air_pump_state = Blockly.Msg["AIRPUMP_ON"];
  } else {
    air_pump_state = Blockly.Msg["AIRPUMP_OFF"];
  }

  code = `robot.air_pump("${air_pump_state}")\n`;
  return code;
}



Blockly.Blocks['axis_move_distance'] = {
  init: function () {
    this.jsonInit({
      "type": "axis_move_distance",
      "message0": "%1 %{BKY_AXIS} %2 %{BKY_MOVE} %3 %{BKY_MILLIMETER} %{BKY_SPEED} %4",
      "args0": [
          {
            "type": "field_dropdown",
            "name": "axis_value",
            "options": [
              ["x", "x"],
              ["y", "y"],
              ["z", "z"]
            ]
          },
          {
            "type": "field_dropdown",
            "name": "direction_value",
            "options": [
                ["%{BKY_FORWARD}", "0"],
                ["%{BKY_BACKWARD}", "1"]
            ]
          },
          {
            "type": "field_number",
            "name": "distance_value",
            "value": 0,
            "min": 0,
            "max": 500,
            "precision": 1
          },
          {
            "type": "field_number",
            "name": "speed_value",
            "value": 0,
            "min": 5,
            "max": 40,
            "precision": 1
          },
      ],
      "inputsInline": true,
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#36B7F4",
      "tooltip": "",
      "helpUrl": ""
    });
  }
};

Blockly.JavaScript['axis_move_distance'] = function (block) {
  const axis_value = block.getFieldValue('axis_value');
  const direction_value = block.getFieldValue('direction_value');
  const speed_value = block.getFieldValue("speed_value");
  let distance_value = block.getFieldValue('distance_value');

  let servo = '';

  switch(axis_value) {
    case 'x':
      servo = '01';
      break;
    case 'y':
      servo = '02';
      break;
    case 'z':
      servo = '03';
      break;
  };

  let code = '';

  distance_value = !Number.parseInt(direction_value, 10) ? Number.parseInt(distance_value, 10) : ~Number.parseInt(distance_value, 10) + 1;
  let distance_value_high = ((distance_value >> 8) & 0xFF).toString(16).toUpperCase();
  let distance_value_low = (distance_value & 0xFF).toString(16).toLocaleUpperCase();

  const speed = (Number.parseInt(speed_value, 10)).toString(16).toLocaleUpperCase();

  return code.concat(`FORWARDINVERSEKIT ${distance_value_high} ${distance_value_low} ${speed} ${servo}\n`).concat(`WAIT\n`);
}

Blockly.Python['axis_move_distance'] = function (block) {
  const axis_value = block.getFieldValue('axis_value');
  let direction_value = block.getFieldValue('direction_value');
  direction_value = !Number.parseInt(direction_value, 10) ? Blockly.Msg['FORWARD'] : Blockly.Msg['BACKWARD'];
  const distance_value = block.getFieldValue('distance_value');
  const speed_value = block.getFieldValue("speed_value");

  return `robot.axis_move_distance('${axis_value}', '${direction_value}', ${distance_value}, ${speed_value})\n`;
}



Blockly.Blocks['delay'] = {
  init: function () {
    this.jsonInit({
      "type": "delay",
      "message0": "%{BKY_DELAY} %1 %{BKY_DELAY_TIME}",
      "args0": [
        {
          "type": "field_number",
          "name": "delay",
          "value": 0,
          "min": 0,
          "max": 9999,
          "precision": 1
        }
      ],
      "previousStatement": null,
      "nextStatement": null,
      "colour": '#36B7F4',
      "tooltip": "",
      "helpUrl": ""
    });
  }
};

Blockly.JavaScript['delay'] = function (block) {
  var code = "";
  
  var delayms = parseInt(block.getFieldValue("delay"), 0);
  if (!isNaN(delayms)) {
    if (delayms > 9999) {
      delayms = 9999;
    }
    var delayms_high, delayms_low;
    while (delayms >= 4000) {
      delayms_high = (4000 >> 8) & 0xff;
      delayms_low = (4000) & 0xff;
      code = code + `DELAY ${delayms_high.toString(16).toUpperCase()} ${delayms_low.toString(16).toUpperCase()}\n`;
      delayms = delayms - 4000;
    }
    if (delayms > 0) {
      delayms_high = (delayms >> 8) & 0xff;
      delayms_low = (delayms) & 0xff;
      code = code + `DELAY ${delayms_high.toString(16).toUpperCase()} ${delayms_low.toString(16).toUpperCase()}\n`;
    }
  }
  
  return code;
}

Blockly.Python['delay'] = function (block) {
  var code = "";
  // var delayms = parseInt(Blockly.JavaScript.valueToCode(block, "delay", Blockly.JavaScript.ORDER_NONE), 0);
  var delayms = block.getFieldValue("delay");

  code = `robot.delayms(${delayms})\n`;
  
  return code;
}



Blockly.Blocks['gamepad'] = {
  init: function () {
    this.jsonInit({
      "type": "gamepad",
      "message0": "%{BKY_GAMEPAD} %1 %{BKY_GAMEPAD_VAR} %2",
      "args0": [{
        "type": "input_dummy"
      }, {
        "type": "input_value",
        "name": "variable",
        "check": "Variable"
      }],
      "previousStatement": null,
      "nextStatement": null,
      "colour": '#36B7F4',
      "tooltip": "",
      "helpUrl": ""
    });
  }
};

Blockly.JavaScript['gamepad'] = function (block) {
  var variable = Blockly.JavaScript.valueToCode(block, "variable", Blockly.JavaScript.ORDER_NONE);
  var code = "";
  if(variable) {
    var jmp_id_1 = "id-" + md5(block.id) + "-1";
    var jmp_id_2 = "id-" + md5(block.id) + "-2";
    code = `ASSIGNMENT 10 00 ${variable} 00 00\nLABEL ${jmp_id_1}\nCMP 10 00 ${variable} 00 00\nJNE ${jmp_id_2}\nRX ${variable}\nJMP ${jmp_id_1}\nLABEL ${jmp_id_2}\n`;
  }

  return code;
}

Blockly.Python['gamepad'] = function (block) {
  var variable = Blockly.Python.valueToCode(block, "variable", Blockly.Python.ORDER_NONE);
  var code = "";
  if(variable) {
    code = `${variable} = robot.remote()\n`;
  } else {
    code = `robot.remote(None)\n`;
  }

  return code;
}



Blockly.Blocks['servo_1_rotate_direction'] = {
  init: function () {
    this.jsonInit({
      "type": "servo_1_rotate_direction",
      "message0": "%{BKY_SERVO} 1 %1 %{BKY_ROTATE} %2 %{BKY_DEGREE} %{BKY_SPEED} %3",
      "args0": [
        {
          "type": "field_dropdown",
          "name": "direction_value",
          "options": [
            ["%{BKY_CLOCKWISE}", "0"],
            ["%{BKY_ANTI_CLOCKWISE}", "1"]
          ]
        },
        {
          "type": "field_number",
          "name": "degree_value",
          "value": 0,
          "min": 0,
          "max": 180,
          "precision": 0.1
        },
        {
          "type": "field_number",
          "name": "speed_value",
          "value": 0,
          "min": 5,
          "max": 40,
          "precision": 1
        }
    ],
    "inputsInline": true,
    "previousStatement": null,
    "nextStatement": null,
    "colour": "#36B7F4",
    "tooltip": "",
    "helpUrl": ""
    });
  }
};

Blockly.JavaScript['servo_1_rotate_direction'] = function (block) {
  const degree_value = block.getFieldValue("degree_value");
  const speed_value = block.getFieldValue("speed_value");

  let direction_value = block.getFieldValue("direction_value");

  let code = '';

  distance_value = !Number.parseInt(direction_value, 10) ? Number.parseFloat(degree_value, 10) * 10 : (~Number.parseFloat(degree_value, 10) + 1) * 10;

  let distance_value_high = ((distance_value >> 8) & 0xFF).toString(16).toUpperCase();
  let distance_value_low = (distance_value & 0xFF).toString(16).toLocaleUpperCase();

  const speed = (Number.parseInt(speed_value, 10)).toString(16).toLocaleUpperCase();

  return code.concat(`RDPOSITIONMOV ${distance_value_high} ${distance_value_low} ${speed} 01\n`).concat('WAIT\n');
}

Blockly.Python['servo_1_rotate_direction'] = function (block) {
  const degree_value = block.getFieldValue("degree_value");

  const speed_value = block.getFieldValue("speed_value");

  let direction_value = block.getFieldValue("direction_value");
  direction_value =  direction_value === 1 ?  Blockly.Msg["ANTI_CLOCKWISE"] : Blockly.Msg["CLOCKWISE"];

  return `robot.servo_rotate_direction(1, '${direction_value}', ${degree_value}, ${speed_value})\n`;
}



Blockly.Blocks['servo_2_rotate_direction'] = {
  init: function () {
    this.jsonInit({
      "type": "servo_2_rotate_direction",
      "message0": "%{BKY_SERVO} 2 %1 %{BKY_ROTATE} %2 %{BKY_DEGREE} %{BKY_SPEED} %3",
      "args0": [
        {
          "type": "field_dropdown",
          "name": "direction_value",
          "options": [
            ["%{BKY_MOVE_FORWARD}", "0"],
            ["%{BKY_MOVE_BACKWARD}", "1"]
          ]
        },
        {
          "type": "field_number",
          "name": "degree_value",
          "value": 0,
          "min": 0,
          "max": 65,
          "precision": 0.1
        },
        {
          "type": "field_number",
          "name": "speed_value",
          "value": 0,
          "min": 5,
          "max": 40,
          "precision": 1
        }
    ],
    "inputsInline": true,
    "previousStatement": null,
    "nextStatement": null,
    "colour": "#36B7F4",
    "tooltip": "",
    "helpUrl": ""
    });
  }
};

Blockly.JavaScript['servo_2_rotate_direction'] = function (block) {
  const degree_value = block.getFieldValue("degree_value");
  const speed_value = block.getFieldValue("speed_value");

  let direction_value = block.getFieldValue("direction_value");

  let code = '';

  distance_value = !Number.parseInt(direction_value, 10) ? Number.parseFloat(degree_value, 10) * 10 : (~Number.parseFloat(degree_value, 10) + 1) * 10;

  let distance_value_high = ((distance_value >> 8) & 0xFF).toString(16).toUpperCase();
  let distance_value_low = (distance_value & 0xFF).toString(16).toLocaleUpperCase();

  const speed = (Number.parseInt(speed_value, 10)).toString(16).toLocaleUpperCase();

  return code.concat(`RDPOSITIONMOV ${distance_value_high} ${distance_value_low} ${speed} 02\n`).concat('WAIT\n');
}

Blockly.Python['servo_2_rotate_direction'] = function (block) {
  const degree_value = block.getFieldValue("degree_value");
  const speed_value = block.getFieldValue("speed_value");

  let direction_value = block.getFieldValue("direction_value");
  direction_value =  direction_value === 1 ?  Blockly.Msg["MOVE_BACKWARD"] : Blockly.Msg["MOVE_FORWARD"];

  return `robot.servo_rotate_direction(2, '${direction_value}', ${degree_value}, ${speed_value})\n`;
}



Blockly.Blocks['servo_3_rotate_direction'] = {
  init: function () {
    this.jsonInit({
      "type": "servo_1_rotate_direction",
      "message0": "%{BKY_SERVO} 3 %1 %{BKY_ROTATE} %2 %{BKY_DEGREE} %{BKY_SPEED} %3",
      "args0": [
        {
          "type": "field_dropdown",
          "name": "direction_value",
          "options": [
            ["%{BKY_MOVE_DOWNWARD}", "0"],
            ["%{BKY_MOVE_UPWARD}", "1"]
          ]
        },
        {
          "type": "field_number",
          "name": "degree_value",
          "value": 0,
          "min": 0,
          "max": 65,
          "precision": 0.1
        },
        {
          "type": "field_number",
          "name": "speed_value",
          "value": 0,
          "min": 5,
          "max": 40,
          "precision": 1
        }
    ],
    "inputsInline": true,
    "previousStatement": null,
    "nextStatement": null,
    "colour": "#36B7F4",
    "tooltip": "",
    "helpUrl": ""
    });
  }
};

Blockly.JavaScript['servo_3_rotate_direction'] = function (block) {
  const degree_value = block.getFieldValue("degree_value");
  const speed_value = block.getFieldValue("speed_value");

  let direction_value = block.getFieldValue("direction_value");

  let code = '';

  distance_value = !Number.parseInt(direction_value, 10) ? Number.parseFloat(degree_value, 10) * 10 : (~Number.parseFloat(degree_value, 10) + 1) * 10;

  let distance_value_high = ((distance_value >> 8) & 0xFF).toString(16).toUpperCase();
  let distance_value_low = (distance_value & 0xFF).toString(16).toLocaleUpperCase();

  const speed = (Number.parseInt(speed_value, 10)).toString(16).toLocaleUpperCase();

  return code.concat(`RDPOSITIONMOV ${distance_value_high} ${distance_value_low} ${speed} 03\n`).concat('WAIT\n');
}

Blockly.Python['servo_3_rotate_direction'] = function (block) {
  const degree_value = block.getFieldValue("degree_value");
  const speed_value = block.getFieldValue("speed_value");

  let direction_value = block.getFieldValue("direction_value");
  direction_value =  direction_value === 1 ?  Blockly.Msg["MOVE_UPWARD"] : Blockly.Msg["MOVE_DOWNWARD"];

  return `robot.servo_rotate_direction(3, '${direction_value}', ${degree_value}, ${speed_value})\n`;
}



Blockly.Blocks['start'] = {
  init: function () {
    this.jsonInit({
      "type": "start",
      "message0": "%{BKY_START} %1 %2",
      "args0": [{
        "type": "input_dummy"
      }, {
        "type": "input_statement",
        "name": "do"
      }],
      "colour": '#86C113',
      "tooltip": "",
      "helpUrl": ""
    });
    this.setDeletable(false);
  }
};

Blockly.JavaScript['start'] = function (block) {
  var do_code = Blockly.JavaScript.statementToCode(block, "do");
  var code = `${do_code}RET`;

  return code;
}

Blockly.Python['start'] = function (block) {
  var do_code = Blockly.Python.statementToCode(block, "do");
  var code = `import aelossdk\nfrom aelosvars import *\nrobot = aelossdk.init()\n\n${do_code}`;

  return code;
}



