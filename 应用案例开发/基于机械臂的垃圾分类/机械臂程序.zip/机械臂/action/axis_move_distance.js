Blockly.Blocks['axis_move_distance'] = {
  init: function () {
    this.jsonInit({
      "type": "axis_move_distance",
      "message0": "%1 %{BKY_AXIS} %2 %{BKY_MOVE} %3 %{BKY_MILLIMETER} %{BKY_SPEED} %4",
      "args0": [
          {
            "type": "field_dropdown",
            "name": "axis_value",
            "options": [
              ["x", "x"],
              ["y", "y"],
              ["z", "z"]
            ]
          },
          {
            "type": "field_dropdown",
            "name": "direction_value",
            "options": [
                ["%{BKY_FORWARD}", "0"],
                ["%{BKY_BACKWARD}", "1"]
            ]
          },
          {
            "type": "field_number",
            "name": "distance_value",
            "value": 0,
            "min": 0,
            "max": 500,
            "precision": 1
          },
          {
            "type": "field_number",
            "name": "speed_value",
            "value": 0,
            "min": 5,
            "max": 40,
            "precision": 1
          },
      ],
      "inputsInline": true,
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#36B7F4",
      "tooltip": "",
      "helpUrl": ""
    });
  }
};

Blockly.JavaScript['axis_move_distance'] = function (block) {
  const axis_value = block.getFieldValue('axis_value');
  const direction_value = block.getFieldValue('direction_value');
  const speed_value = block.getFieldValue("speed_value");
  let distance_value = block.getFieldValue('distance_value');

  let servo = '';

  switch(axis_value) {
    case 'x':
      servo = '01';
      break;
    case 'y':
      servo = '02';
      break;
    case 'z':
      servo = '03';
      break;
  };

  let code = '';

  distance_value = !Number.parseInt(direction_value, 10) ? Number.parseInt(distance_value, 10) : ~Number.parseInt(distance_value, 10) + 1;
  let distance_value_high = ((distance_value >> 8) & 0xFF).toString(16).toUpperCase();
  let distance_value_low = (distance_value & 0xFF).toString(16).toLocaleUpperCase();

  const speed = (Number.parseInt(speed_value, 10)).toString(16).toLocaleUpperCase();

  return code.concat(`FORWARDINVERSEKIT ${distance_value_high} ${distance_value_low} ${speed} ${servo}\n`).concat(`WAIT\n`);
}

Blockly.Python['axis_move_distance'] = function (block) {
  const axis_value = block.getFieldValue('axis_value');
  let direction_value = block.getFieldValue('direction_value');
  direction_value = !Number.parseInt(direction_value, 10) ? Blockly.Msg['FORWARD'] : Blockly.Msg['BACKWARD'];
  const distance_value = block.getFieldValue('distance_value');
  const speed_value = block.getFieldValue("speed_value");

  return `robot.axis_move_distance('${axis_value}', '${direction_value}', ${distance_value}, ${speed_value})\n`;
}

