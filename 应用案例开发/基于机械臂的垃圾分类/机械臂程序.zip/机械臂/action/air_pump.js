Blockly.Blocks['air_pump'] = {
  init: function () {
    this.jsonInit({
      "type": "air_pump",
      "message0": "%{BKY_AIRPUMP} %1",
      "args0": [
        {
          "type": "field_dropdown",
          "name": "output_value",
          "options": [
            [
              "%{BKY_AIRPUMP_OFF}",
              "0"
            ],
            [
              "%{BKY_AIRPUMP_ON}",
              "1"
            ]
          ]
        }
      ],
      "previousStatement": null,
      "nextStatement": null,
      "colour": "#36B7F4",
      "tooltip": "",
      "helpUrl": ""
    })
  }
};

Blockly.JavaScript['air_pump'] = function (block) {
  var code = '';
  var output_value = block.getFieldValue("output_value");

  if(output_value){
    output_value = Blockly.JavaScript.transferHex(output_value, 1);
    code = `IOout 07 ${output_value}\n`;
  }

  return code;
}

Blockly.Python['air_pump'] = function (block) {
  var code = '';
  var output_value = parseInt(block.getFieldValue("output_value"), 0);
  var air_pump_state;
  if(output_value === 1){
    air_pump_state = Blockly.Msg["AIRPUMP_ON"];
  } else {
    air_pump_state = Blockly.Msg["AIRPUMP_OFF"];
  }

  code = `robot.air_pump("${air_pump_state}")\n`;
  return code;
}

