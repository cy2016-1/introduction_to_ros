Blockly.Blocks['servo_1_rotate_direction'] = {
  init: function () {
    this.jsonInit({
      "type": "servo_1_rotate_direction",
      "message0": "%{BKY_SERVO} 1 %1 %{BKY_ROTATE} %2 %{BKY_DEGREE} %{BKY_SPEED} %3",
      "args0": [
        {
          "type": "field_dropdown",
          "name": "direction_value",
          "options": [
            ["%{BKY_CLOCKWISE}", "0"],
            ["%{BKY_ANTI_CLOCKWISE}", "1"]
          ]
        },
        {
          "type": "field_number",
          "name": "degree_value",
          "value": 0,
          "min": 0,
          "max": 180,
          "precision": 0.1
        },
        {
          "type": "field_number",
          "name": "speed_value",
          "value": 0,
          "min": 5,
          "max": 40,
          "precision": 1
        }
    ],
    "inputsInline": true,
    "previousStatement": null,
    "nextStatement": null,
    "colour": "#36B7F4",
    "tooltip": "",
    "helpUrl": ""
    });
  }
};

Blockly.JavaScript['servo_1_rotate_direction'] = function (block) {
  const degree_value = block.getFieldValue("degree_value");
  const speed_value = block.getFieldValue("speed_value");

  let direction_value = block.getFieldValue("direction_value");

  let code = '';

  distance_value = !Number.parseInt(direction_value, 10) ? Number.parseFloat(degree_value, 10) * 10 : (~Number.parseFloat(degree_value, 10) + 1) * 10;

  let distance_value_high = ((distance_value >> 8) & 0xFF).toString(16).toUpperCase();
  let distance_value_low = (distance_value & 0xFF).toString(16).toLocaleUpperCase();

  const speed = (Number.parseInt(speed_value, 10)).toString(16).toLocaleUpperCase();

  return code.concat(`RDPOSITIONMOV ${distance_value_high} ${distance_value_low} ${speed} 01\n`).concat('WAIT\n');
}

Blockly.Python['servo_1_rotate_direction'] = function (block) {
  const degree_value = block.getFieldValue("degree_value");

  const speed_value = block.getFieldValue("speed_value");

  let direction_value = block.getFieldValue("direction_value");
  direction_value =  direction_value === 1 ?  Blockly.Msg["ANTI_CLOCKWISE"] : Blockly.Msg["CLOCKWISE"];

  return `robot.servo_rotate_direction(1, '${direction_value}', ${degree_value}, ${speed_value})\n`;
}

